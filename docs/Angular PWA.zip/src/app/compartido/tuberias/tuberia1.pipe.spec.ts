import { Tuberia1Pipe } from './tuberia1.pipe';

describe('Tuberia1Pipe', () => {
  it('create an instance', () => {
    const pipe = new Tuberia1Pipe();
    expect(pipe).toBeTruthy();
  });
});
