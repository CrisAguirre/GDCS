import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tuberia1'
})
export class Tuberia1Pipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return null;
  }

}
