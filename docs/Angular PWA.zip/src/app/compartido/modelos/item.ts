export class Item {
    name: string;
    description: string;
    url: string;
    html: string;
    markdown: string;
}
