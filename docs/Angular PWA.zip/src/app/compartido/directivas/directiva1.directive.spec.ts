import { Directiva1Directive } from './directiva1.directive';

describe('Directiva1Directive', () => {
  it('should create an instance', () => {
    const directive = new Directiva1Directive();
    expect(directive).toBeTruthy();
  });
});
