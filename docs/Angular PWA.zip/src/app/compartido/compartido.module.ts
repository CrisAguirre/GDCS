import { HeaderComponent } from '@compartido/componentes/header/header.component';
import { FooterComponent } from './componentes/footer/footer.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DatePickerComponent } from './componentes/date-picker/date-picker.component';
import { SpinnerComponent } from './componentes/spinner/spinner.component';
import { Directiva1Directive } from './directivas/directiva1.directive';
import { Tuberia1Pipe } from './tuberias/tuberia1.pipe';

@NgModule({
  declarations: [
    DatePickerComponent,
    SpinnerComponent,
    Directiva1Directive,
    Tuberia1Pipe,
    FooterComponent,
    HeaderComponent
  ],
  exports: [
    DatePickerComponent,
    SpinnerComponent,
    Directiva1Directive,
    Tuberia1Pipe,
    FooterComponent,
    HeaderComponent
  ],
  imports: [
    CommonModule
  ]
})
export class CompartidoModule { }
