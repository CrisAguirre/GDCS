import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('@modulos/inicio/inicio.module').then(m => m.InicioModule)
  },
  {
    path: 'administracion',
    loadChildren: () =>
      import('@modulos/administracion/administracion.module').then(m => m.AdministracionModule)
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
