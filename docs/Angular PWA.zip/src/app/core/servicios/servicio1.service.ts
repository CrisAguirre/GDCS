import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Servicio1Service {

  propiedadPrueba = 'Test';

  constructor() { }
}
