import { Item } from './../../../../compartido/modelos/item';
import { Servicio1Service } from '@app/servicios/servicio1.service';
import { Component, OnInit } from '@angular/core'; 
import { ApiService } from '@app/servicios/api.service';

@Component({
  selector: 'sl-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.scss']
})
export class InicioComponent implements OnInit {

  listaItems: Item[];

  constructor(private servicio: Servicio1Service, private api: ApiService ) { }

  ngOnInit() {
    console.log(this.servicio.propiedadPrueba);
    this.api.fetch().subscribe(data => {
      console.log(data);
      this.listaItems = data;
    });
  }

}
