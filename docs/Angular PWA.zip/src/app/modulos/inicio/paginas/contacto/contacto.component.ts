import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sl-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.scss']
})
export class ContactoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
