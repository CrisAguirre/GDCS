import { CompartidoModule } from '@compartido/compartido.module';
import { CoreModule } from '@app/core.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InicioRoutingModule } from './inicio-routing.module';
import { InicioComponent } from './paginas/inicio/inicio.component';
import { ContactoComponent } from './paginas/contacto/contacto.component';
import { FormularioComponent } from './componentes/formulario/formulario.component';
import { ModalComponent } from './componentes/modal/modal.component';
import { BienvenidaComponent } from './paginas/bienvenida/bienvenida.component';


@NgModule({
  declarations: [
    InicioComponent,
    ContactoComponent,
    FormularioComponent,
    ModalComponent,
    BienvenidaComponent
  ],
  imports: [
    CommonModule,
    InicioRoutingModule,
    CompartidoModule
  ]
})
export class InicioModule { }
