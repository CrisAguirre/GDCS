import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sl-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.scss']
})
export class FormularioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
